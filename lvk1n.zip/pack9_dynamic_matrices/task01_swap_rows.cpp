#include <iostream>
using namespace std;

int** createMatrix(int m, int n) {
    int** a = new int*[m];
    for (int i = 0; i < m; i++) a[i] = new int[n];
    return a;
}

void fillMatrix(int** a, int m, int n) {
    for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++)
            cin >> a[i][j];
}

void printMatrix(int** a, int m, int n) {
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) cout << a[i][j] << " ";
        cout << "\n";
    }
}

void freeMatrix(int** a, int m) {
    for (int i = 0; i < m; i++) delete[] a[i];
    delete[] a;
}

void removeRow(int**& a, int& m, int r) {
    int** b = new int*[m - 1];
    for (int i = 0; i < r; i++) b[i] = a[i];
    delete[] a[r];
    for (int i = r + 1; i < m; i++) b[i - 1] = a[i];
    delete[] a;
    a = b;
    m--;
}

void insertRow(int**& a, int& m, int r, int* row) {
    int** b = new int*[m + 1];
    for (int i = 0; i < r; i++) b[i] = a[i];
    b[r] = row;
    for (int i = r; i < m; i++) b[i + 1] = a[i];
    delete[] a;
    a = b;
    m++;
}

void removeColumn(int** a, int m, int& n, int c) {
    for (int i = 0; i < m; i++) {
        int* row = new int[n - 1];
        for (int j = 0; j < c; j++) row[j] = a[i][j];
        for (int j = c + 1; j < n; j++) row[j - 1] = a[i][j];
        delete[] a[i];
        a[i] = row;
    }
    n--;
}

void insertColumn(int** a, int m, int& n, int c, int val) {
    for (int i = 0; i < m; i++) {
        int* row = new int[n + 1];
        for (int j = 0; j < c; j++) row[j] = a[i][j];
        row[c] = val;
        for (int j = c; j < n; j++) row[j + 1] = a[i][j];
        delete[] a[i];
        a[i] = row;
    }
    n++;
}

int main() {
    int m, n;
    cin >> m >> n;
    int** a = createMatrix(m, n);
    fillMatrix(a, m, n);

    int k1, k2;
    cin >> k1 >> k2;
    int* t = a[k1 - 1];
    a[k1 - 1] = a[k2 - 1];
    a[k2 - 1] = t;
    printMatrix(a, m, n);
    freeMatrix(a, m);
    return 0;
}
