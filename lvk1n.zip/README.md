# lvk1n: C++ task packs 5-10

Каждая папка — один пакет заданий, каждый файл — отдельная задача (полная программа).

| Папка | Тема | Задач |
|---|---|---|
| pack5_algorithms | Algorithms | 9 |
| pack6_multidimensional_arrays | Multidimensional arrays | 20 |
| pack7_recursion | Recursion | 5 |
| pack8_dynamic_arrays | Dynamic arrays | 13 |
| pack9_dynamic_matrices | Dynamic two dimensional arrays | 16 |
| pack10_strings | String | 24 |

Компиляция: `g++ -std=c++17 pack5_algorithms/task01_neighbors.cpp -o task && ./task`
